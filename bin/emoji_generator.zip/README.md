# Emoji Generator (... or maybe translator)

Link to source code: https://github.com/ivanasen/emoji_generator

## Project structure
- Main documentation of the project is in `notebooks/final.ipynb`.
  The documentation is a Jupyter notebook so it is a mixture of
  docs, and code showing our results.
- Source code is in `/src`.
